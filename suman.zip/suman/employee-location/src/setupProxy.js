const { createProxyMiddleware } = require('http-proxy-middleware');
module.exports = function (app) {
    app.use(
        '/india',
        createProxyMiddleware({
            target: 'http://localhost:5004',
            changeOrigin: true,
            pathRewrite: {
                "^/india": "/india"
            }
        })
    );
};