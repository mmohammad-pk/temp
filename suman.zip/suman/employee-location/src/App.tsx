import React from 'react';
import './App.css';
import Header from './components/header/Header';
import {
  BrowserRouter as Router,
  Route,
  Link,
  Switch
} from 'react-router-dom';
import Map from './components/map/Map';
import EmployeeSearch from './components/employee-search/EmployeeSearch';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';

function App() {
  return (
    <Router>
      <div id="viewport">
        <div className="app-header">
          <Header></Header>
        </div>
        <div id="sidebar">
          <div className="nav-row">
            <div className="nav-item">
              <Link to="/"><i className="zmdi zmdi-pin"></i> Hyderabad</Link>
            </div>
          </div>
          <div className="nav-row">
            <div className="nav-item">
              <Link to="/EmployeeSearch"><i className="zmdi zmdi-local-wc"></i> Employee Search</Link>
            </div>
          </div>

        </div>
        <div id="content">
          <div className="container-fluid route-main">
            <Switch>
              <Route exact path='/' component={Map}></Route>
              <Route exact path='/EmployeeSearch' component={EmployeeSearch}></Route>
            </Switch>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
