import React, { Component } from 'react';

class Test extends Component<{ rows: string[] }, { test: string }> {


    constructor(props: any) {
        super(props);
    }

    render() {
        return (
            <div>
                Hello
            </div>

        );
    }
}

export default Test;
