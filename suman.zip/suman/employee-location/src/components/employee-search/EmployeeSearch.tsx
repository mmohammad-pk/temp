import React, { Component } from 'react';
import './EmployeeSearch.css';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { TextField } from '@material-ui/core';
import StickyHeadTable from '../grid/StickyHeadTable';


class EmployeeSearch extends Component<{}, { locations: Array<any>, selectedClient: string, rows: Array<any>, clients: Array<string>, projects: Array<any>, latLong: any, selectedKms: string, kms: Array<string> }> {

    constructor(props: any) {
        super(props);
        this.state = {
            locations: [],
            rows: [],
            clients: [],
            projects: [],
            latLong: null,
            kms: ['1', '3', '4', '5', '10', '50', '100'],
            selectedKms: '10',
            selectedClient: ''
        }
    }

    componentDidMount() {
        fetch("/india/telangana/hyderabad/areas")
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.length > 0) {
                        this.setState({ locations: result });
                    }
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    console.log(error);
                }
            );
    }

    selectedValue(value: any) {
        console.log(value);
    }

    getAllEmployees = (reqObj: any) => {
        fetch("/india/telangana/hyderabad/employees", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(reqObj)
        })
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.length > 0) {
                        this.setState({ rows: result });
                        const uniqueClients = new Set<string>();
                        result.forEach((item: any) => uniqueClients.add(item['Client']));
                        if (uniqueClients.size > 0) {
                            const newClients: Array<string> = [];
                            uniqueClients.forEach((item: string) => newClients.push(item));
                            this.setState({ clients: newClients });
                        }

                        const uniqueProjects = new Set<string>();
                        result.forEach((item: any) => uniqueProjects.add(item['Project'] + '||' + item['Client']));
                        if (uniqueProjects.size > 0) {
                            const newProjects: Array<any> = [];
                            uniqueProjects.forEach((item: string) => newProjects.push({ project: item.split('||')[0], client: item.split('||')[1] }));
                            this.setState({ projects: newProjects });
                        }
                    }
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    console.log(error);
                }
            );
    }

    locationChange = (event: any) => {
        const selectedValue = event.currentTarget.innerText;
        const selectedObj = this.state.locations.filter(item => item.Area === selectedValue);
        if (selectedObj && selectedObj.length > 0) {
            const latLong = JSON.parse(selectedObj[0].pin.replace(/\'/g, '\"'));
            this.setState({ latLong });
            const reqObj = {
                geolocation: {
                    lat: latLong.location.lat,
                    lng: latLong.location.lon
                },
                distance: this.state.selectedKms
            };
            this.getAllEmployees(reqObj);
        } else {
            this.setState({ rows: [], clients: [], projects: [] });
        }
    }

    clientsChange = (event: any) => {
        const selectedValue = event.currentTarget.innerText;
        const latLong = this.state.latLong;
        if (selectedValue) {
            this.setState({ selectedClient: selectedValue });
        } else {
            this.setState({ selectedClient: '' });
        }
        const reqObj = {
            geolocation: {
                lat: latLong.location.lat,
                lng: latLong.location.lon
            },
            distance: this.state.selectedKms,
            client: selectedValue ? selectedValue : null

        };
        this.getAllEmployees(reqObj);
    }

    projectsChange = (event: any) => {
        const selectedValue = event.currentTarget.innerText;
        const selectedObj: any = this.state.projects.filter(item => item.project === selectedValue);
        const latLong = this.state.latLong;
        const reqObj = {
            geolocation: {
                lat: latLong.location.lat,
                lng: latLong.location.lon
            },
            distance: this.state.selectedKms,
            client: this.state.selectedClient ? this.state.selectedClient : null,
            project: selectedObj && selectedObj.length > 0 ? selectedObj[0].project : null,
        };
        this.getAllEmployees(reqObj);
    }

    kmsChange = (event: any) => {
        const selectedValue = event.currentTarget.innerText;
        this.setState({ selectedKms: selectedValue });
    }

    render() {
        return <div className="es-main">
            <div className="es-header">

                <div className="search-group">
                    <div>
                        <Autocomplete
                            id="combo-box-demo"
                            options={this.state.kms}
                            getOptionLabel={(option) => option}
                            defaultValue={this.state.selectedKms}
                            onChange={(event: any) => this.kmsChange(event)}
                            style={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Kms" variant="outlined" />}
                        />
                    </div>
                    <div>
                        <Autocomplete
                            id="combo-box-demo"
                            options={this.state.locations}
                            getOptionLabel={(option) => option.Area}
                            onChange={(event: any) => this.locationChange(event)}
                            style={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Locations" variant="outlined" />}
                        />
                    </div>
                    <div>
                        <Autocomplete
                            id="combo-box-demo"
                            options={this.state.clients}
                            getOptionLabel={(option) => option}
                            onChange={(event: any) => this.clientsChange(event)}
                            style={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Clients" variant="outlined" />}
                        />
                    </div>
                    {/* <div>
                    <Autocomplete
                        id="combo-box-demo"
                        options={this.state.projects}
                        getOptionLabel={(option) => option.project}
                        onChange={(event: any) => this.projectsChange(event)}
                        style={{ width: 300 }}
                        renderInput={(params) => <TextField {...params} label="Projects" variant="outlined" />}
                    />
                </div> */}
                </div>
            </div>
            <div className="es-grid-main">
                <StickyHeadTable rows={this.state.rows}></StickyHeadTable>
            </div>
        </div>;
    }
}

export default EmployeeSearch;
