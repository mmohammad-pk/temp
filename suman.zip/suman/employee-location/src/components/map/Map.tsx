import React from 'react';
import './Map.css';

function Map() {
    return (
        <div className="map-main">
            <iframe src="https://www.google.com/maps/d/embed?mid=1JGJbWW1i4HzQzaxyC_fz-YCDOPyjKeAG" width="100%" height="800px"></iframe>
        </div>
    );
}

export default Map;
