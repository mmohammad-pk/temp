import React from 'react';
import './Header.css';

function Header() {
    return (
        <div className="header-main">
            <div className="logo" >
                <img className='pkimg' src='/assets/pk.svg'></img>
            </div>
            <div className="vertical-line">
            </div>
            <div className="edge-logo" >
                <img className="edgeimg" src='/assets/edgemanager.svg'></img>
            </div>
            <div className="edge-header-name" >
                {/* <span className="title"><span className="bold">Employee</span> Cluster</span> */}
            </div >
        </div>
    );
}

export default Header;
