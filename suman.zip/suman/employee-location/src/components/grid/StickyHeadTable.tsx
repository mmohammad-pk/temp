import React, { Component } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';

interface Column {
    id: 'Employee ID' | 'Name' | 'Area' | 'Client' | 'Project';
    label: string;
    minWidth?: number;
    align?: 'right';
    format?: (value: number) => string;
}

const columns: Column[] = [
    { id: 'Employee ID', label: 'Employee ID', minWidth: 170 },
    { id: 'Name', label: 'Name', minWidth: 100 },
    {
        id: 'Client',
        label: 'Client',
        minWidth: 170,
        format: (value: number) => value.toLocaleString(),
    },
    {
        id: 'Area',
        label: 'Area',
        minWidth: 170,
        format: (value: number) => value.toLocaleString(),
    }
    // ,
    // {
    //     id: 'Project',
    //     label: 'Project',
    //     minWidth: 170,
    //     align: 'right',
    //     format: (value: number) => value.toFixed(2),
    // },
];

export class StickyHeadTable extends Component<{ rows: Array<any> }, { classes: any, page: any, setPage: any, rowsPerPage: any, setRowsPerPage: any }> {

    constructor(props: any) {
        super(props);
        const classes = makeStyles({
            root: {
                width: '100%',
            },
            container: {
                maxHeight: 440,
            },
        });
        this.state = {
            classes,
            page: 0,
            setPage: this.handleChangePage,
            rowsPerPage: 10,
            setRowsPerPage: this.handleChangeRowsPerPage
        };
    }

    handleChangePage = (event: unknown, newPage: number) => {
        this.setState({ page: newPage });
    };

    handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        this.setState({ rowsPerPage: +event.target.value });
    };

    render() {
        return (
            <Paper className={this.state.classes.root} >
                <TableContainer className={this.state.classes.container}>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                                {columns.map((column) => (
                                    <TableCell
                                        key={column.id}
                                        align={column.align}
                                        style={{ minWidth: column.minWidth }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {this.props.rows.slice(this.state.page * this.state.rowsPerPage, this.state.page * this.state.rowsPerPage + this.state.rowsPerPage).map((row) => {
                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={row['Employee ID']}>
                                        {columns.map((column) => {
                                            const value = row[column.id];
                                            return (
                                                <TableCell key={column.id} align={column.align}>
                                                    {column.format && typeof value === 'number' ? column.format(value) : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[10, 25, 100]}
                    component="div"
                    count={this.props.rows.length}
                    rowsPerPage={this.state.rowsPerPage}
                    page={this.state.page}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
            </Paper>
        );
    }
}

export default StickyHeadTable;