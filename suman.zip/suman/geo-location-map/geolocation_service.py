import googlemaps


class GeolocationService:

    def __init__(self):
        self.gmaps_key = googlemaps.Client(key="AIzaSyAD_q2HxsD5NDvW5Z-4pbrlSzvVryGm4oQ")

    def get_geolocation(self, address):
        geocode_result = self.gmaps_key.geocode(address.replace("\n", ""))

        try:
            latitude = geocode_result[0]["geometry"]["location"]["lat"]
            longitude = geocode_result[0]["geometry"]["location"]["lng"]
            return latitude, longitude
        except:
            return 0, 0
