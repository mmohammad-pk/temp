from elasticsearch import Elasticsearch
from geolocation_service import GeolocationService


class ElasticSearchService:

    def __init__(self):
        self.es_client = Elasticsearch(http_compress=True)
        self.geolocation_service = GeolocationService()

    def get_employees(self, address, geolocation, distance):
        if not geolocation:
            latitude, longitude = self.geolocation_service.get_geolocation(address)
        else:
            latitude = geolocation.get('lat')
            longitude = geolocation.get('lng')

        str_distance = str(distance) + "km"
        body = {"size": 10000,
                "query": {
                    "bool": {
                        "must": {
                            "match_all": {}
                        },
                        "filter": {
                            "geo_distance": {
                                "distance": str_distance,
                                "pin.location": {
                                    "lat": latitude,
                                    "lon": longitude
                                }
                            }
                        }
                    }
                }
                }

        res = self.es_client.search(index="location_index", body=body)

        employee_list = list()
        for hit in res['hits']['hits']:
            employee_list.append(hit["_source"])
            print(hit["_source"])

        return employee_list
