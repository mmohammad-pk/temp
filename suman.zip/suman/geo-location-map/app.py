from flask import Flask, request, Response
from flask_restful import Resource, Api
from elasticsearch_service import ElasticSearchService
from collections import defaultdict

import logging
import json
import pandas as pd

logger = logging.getLogger('app')
app = Flask(__name__)
api = Api(app)


class LocationService(Resource):
    def post(self):
        request_object = request.json

        address = request_object.get("address")
        geolocation = request_object.get("geolocation")
        client = request_object.get("client")
        project = request_object.get("project")
        distance = request_object.get("distance")

        employees = es_service.get_employees(address, geolocation, distance)

        if client:
            groups = defaultdict(list)

            for obj in employees:
                groups[obj['Client']].append(obj)

            return Response(json.dumps(groups[client]), mimetype='application/json')
        else:
            return Response(json.dumps(employees), mimetype='application/json')


class AreaService(Resource):
    def get(self):
        areas = pd.read_excel('area_geolocations.xlsx')
        areas_list = list()
        for row in areas.iterrows():
            areas_list.append(row[1].to_dict())

        return Response(json.dumps(areas_list), mimetype='application/json')


def main():
    api.add_resource(LocationService, "/india/telangana/hyderabad/employees")
    api.add_resource(AreaService, "/india/telangana/hyderabad/areas")
    app.run(host='0.0.0.0', use_reloader=False, port=5004)


if __name__ == "__main__":
    es_service = ElasticSearchService()
    main()
