import pandas as pd
from geolocation_service import GeolocationService

df = pd.read_excel('area.xlsx')
geolocation_service = GeolocationService()

df["pin"] = None
for i in range(0, len(df), 1):
    address = df.iat[i, 0]
    print(address.replace("\n", ""))
    latitude, longitude = geolocation_service.get_geolocation(address)
    pin = {"location": {"lat": latitude, "lon": longitude}}
    df.iat[i, df.columns.get_loc("pin")] = pin


df.to_excel("area_geolocations.xlsx", index=True)