import pandas
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from geolocation_service import GeolocationService


def populate_geolocations(data):
    data["pin"] = None
    geolocation_service = GeolocationService()
    for i in range(0, len(data), 1):
        address = data.iat[i, 6]
        print(address.replace("\n", ""))
        latitude, longitude = geolocation_service.get_geolocation(address)
        pin = {"location": {"lat": latitude, "lon": longitude}}
        data.iat[i, data.columns.get_loc("pin")] = pin

    return data


use_these_keys = ["Employee ID", "EMP ID", "Name", "Company Dept.", "Current Site", "Reporting Manager",
                  "Mailing Address", "Area", "City", "Pin Code", "Client", "Project", "Status", "pin"]


def filter_keys(document):
    return {key: document[key] for key in use_these_keys}


def delete_existing_data(es_client, document):
    try:
        es_client.delete(index="location_index", id=document['Employee ID'])
    except:
        pass


def doc_generator(df, es_client):
    df_iter = df.iterrows()
    for index, document in df_iter:
        delete_existing_data(es_client, document)
        yield {
            "_index": 'location_index',
            "_type": "_doc",
            "_id": f"{document['Employee ID']}",
            "_source": filter_keys(document),
        }
    raise StopIteration


if __name__ == "__main__":
    data = pandas.read_excel('Sample Address Data.xlsx')
    geo_data = populate_geolocations(data)
    es_client = Elasticsearch(http_compress=True)
    helpers.bulk(es_client, doc_generator(data, es_client))
    print("Completed...")
