ELASTICSEARCH_PROTOCOL=http
ELASTICSEARCH_ENDPOINT=localhost:9600
INDEX_NAME=metadata_index

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/last_run_time -H 'Content-Type: application/json' -d '{
    "type": "last_run_time",
    "data" : {
        "time": 1546281000000
    }
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/tracked_trace_ids -H 'Content-Type: application/json' -d '{
    "type": "tracked_trace_ids",
    "data" : {
        "traceIds": [
            
        ]}
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/frequency_runs_mapping -H 'Content-Type: application/json' -d '{
	"type": "frequency_runs_mapping",
	"data": [
		{
			"frequency": "Daily",
			"runs": 40
		},
		{
			"frequency": "Daily Plus",
			"runs": 40
		},
		{
			"frequency": "Weekly",
			"runs": 12
		},
		{
			"frequency": "Weekly Plus",
			"runs": 12
		},
		{
			"frequency": "Weekdays",
			"runs": 12
		},
		{
			"frequency": "Monthly",
			"runs": 12
		},
		{
			"frequency": "Monthly Plus",
			"runs": 12
		},
		{
			"frequency": "Yearly",
			"runs": 12
		},
		{
			"frequency": "Yearly Plus",
			"runs": 12
		},
		{
			"frequency": "UserTriggered",
			"runs": 12
		}
	]
}'
echo '\n'


curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/group_code_mapping -H 'Content-Type: application/json' -d '{
    "type": "group_code_mapping",
    "data": [
        {
            "process_name": "ForceClosePO",
            "process_code": "FCPO",
            "group": "Finance",
            "group_code": "Fin.047",
            "identifier": "Fin.047-FCPO",
            "description": "ForceClosePO",
            "frequency": "Weekly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ItemMasterMaintain",
            "process_code": "ITMM",
            "group": "Finance",
            "group_code": "Fin.048",
            "identifier": "Fin.048-ITMM",
            "description": "ItemMasterMaint",
            "frequency": "Weekly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ContractUploadToOlive",
            "process_code": "CUTO",
            "group": "Care",
            "group_code": "Care.001",
            "identifier": "Care.001-CUTO",
            "description": "ContUploadToOlive",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "RehireReview",
            "process_code": "HRRR",
            "group": "HR",
            "group_code": "HR.006",
            "identifier": "HR.006-HRRR",
            "description": "RehireReview",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "CapstanInfoForOrder",
            "process_code": "CIFO",
            "group": "Sales",
            "group_code": "Sales.121",
            "identifier": "Sales.121-CIFO",
            "description": "CapstanInfoOrder",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ComplianceReportingActionPlans",
            "process_code": "CRAP",
            "group": "Sales",
            "group_code": "Sales.025",
            "identifier": "Sales.025-CRAP",
            "description": "ComplnceRprtingAct",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "IBSBusinessCaseFundingApproval",
            "process_code": "IBFA",
            "group": "Finance",
            "group_code": "Fin.104",
            "identifier": "Fin.104-IBFA",
            "description": "IBSBizCaseFndingApprvl",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "AutomatedMonthlyTrends",
            "process_code": "AMSR",
            "group": "Finance",
            "group_code": "Fin.098",
            "identifier": "Fin.098-AMSR",
            "description": "AMTSummrzngRprting",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ServiceEnhancementEquipmentOrder",
            "process_code": "SEEO",
            "group": "Care",
            "group_code": "Care.006",
            "identifier": "Care.006-SEEO",
            "description": "ServEnhncmntEqpOrdrPrcssng",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "RunGLDrilldown",
            "process_code": "RGLD",
            "group": "Finance",
            "group_code": "Fin.012",
            "identifier": "Fin.012-RGLD",
            "description": "RunGLDrillDwn",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "PayrollCycleConfirmation",
            "process_code": "PACO",
            "group": "Finance",
            "group_code": "Fin.107",
            "identifier": "Fin.107-PACO",
            "description": "PayrollCycleCnfrmtn",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ProbesHealthChecks",
            "process_code": "PRHC",
            "group": "Network",
            "group_code": "NetWrkOps.021",
            "identifier": "NetWrkOps.021-PRHC",
            "description": "PrbsHlthChks",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ChangeOfOwnership",
            "process_code": "CHOO",
            "group": "Care",
            "group_code": "Care.021",
            "identifier": "Care.021-CHOO",
            "description": "CareChngeOfOwnshp",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "CashVarianceForm",
            "process_code": "CAVF",
            "group": "Sales",
            "group_code": "Sales.026",
            "identifier": "Sales.026-CAVF",
            "description": "CashVrnceForm",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "CollectionsToiCare",
            "process_code": "COTI",
            "group": "Care",
            "group_code": "Care.020",
            "identifier": "Care.020-COTI",
            "description": "CollctnsToiCare",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "NonHSAccessoryReport",
            "process_code": "NHSR",
            "group": "Finance",
            "group_code": "Fin.046",
            "identifier": "Fin.046-NHSR",
            "description": "NonHSAccsryRprt",
            "frequency": "Weekly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ReceiptRetrieval",
            "process_code": "RERE",
            "group": "Finance",
            "group_code": "Fin.135",
            "identifier": "Fin.135-RERE",
            "description": "RecptRtrval",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "WinningReserves",
            "process_code": "RSRV",
            "group": "Finance",
            "group_code": "Fin.127",
            "identifier": "Fin.127-RSRV",
            "description": "Reserves",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "PrimeRateRetrieval",
            "process_code": "PRRR",
            "group": "Finance",
            "group_code": "Fin.128",
            "identifier": "Fin.128-PRRR",
            "description": "PrimeRateRtrval",
            "frequency": "Monthly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "LiborRateRetrieval",
            "process_code": "LIRR",
            "group": "Finance",
            "group_code": "Fin.129",
            "identifier": "Fin.129-LIRR",
            "description": "LiborRateRtrval",
            "frequency": "Monthly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ChangeTicket",
            "process_code": "CHTK",
            "group": "Finance",
            "group_code": "Fin.134",
            "identifier": "Fin.134-CHTK",
            "description": "ChangeTckt",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "KPIPreProcessorFallout",
            "process_code": "KPPF",
            "group": "Finance",
            "group_code": "Fin.133",
            "identifier": "Fin.133-KPPF",
            "description": "KPIPrePrcsrFallout",
            "frequency": "Monthly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "VertexTaxCategoryExtraction",
            "process_code": "VTCE",
            "group": "Finance",
            "group_code": "Fin.139",
            "identifier": "Fin.139-VTCE",
            "description": "VertexTaxCtgryExtrctn",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "OutlierFollowUpNotifications",
            "process_code": "OFUN",
            "group": "Finance",
            "group_code": "Fin.140",
            "identifier": "Fin.140-OFUN",
            "description": "OutlierFllwupNtfctn",
            "frequency": "Monthly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "MonthToMonthTaxReturn",
            "process_code": "MMTC",
            "group": "Finance",
            "group_code": "Fin.141",
            "identifier": "Fin.141-MMTC",
            "description": "Mnth2MnthTxCmprsn",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ExpenseReportReview",
            "process_code": "EXRR",
            "group": "Finance",
            "group_code": "Fin.115",
            "identifier": "Fin.115-EXRR",
            "description": "ExpnseRprtRvw",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "OfferManagement",
            "process_code": "OFMG",
            "group": "B2B",
            "group_code": "B2B.009",
            "identifier": "B2B.009-OFMG",
            "description": "OffrMgmt",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "GLDrilldownFullReconciliation",
            "process_code": "GLDF",
            "group": "Finance",
            "group_code": "Fin.142",
            "identifier": "Fin.142-GLDF",
            "description": "GLDrillDwnFullRecnclltn",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "GLDrilldownAlteryx",
            "process_code": "GLDA",
            "group": "Finance",
            "group_code": "Fin.144",
            "identifier": "Fin.144-GLDA",
            "description": "GLDrillDwnAltryx",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ContractSignatureValidation",
            "process_code": "CSV",
            "group": "Finance",
            "group_code": "Fin.039",
            "identifier": "Fin.039-CSV",
            "description": "ContractSignatureValidation",
            "frequency": "Weekdays",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "IICEAndOliveInvoice",
            "process_code": "IIOI",
            "group": "Finance",
            "group_code": "Fin.143",
            "identifier": "Fin.143-IIOI",
            "description": "IICE and Olive innvoices",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ValidateVendorStatus",
            "process_code": "VVES",
            "group": "Finance",
            "group_code": "Fin.145",
            "identifier": "Fin.145-VVES",
            "description": "ValidateVendorStatus",
            "frequency": "Weekly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "SoxScedhuleCreation",
            "process_code": "SSC",
            "group": "Finance",
            "group_code": "Fin.146",
            "identifier": "Fin.146-SSC",
            "description": "SoxScedhuleCreation",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "DailyMissingSubsQuery",
            "process_code": "DMSQ",
            "group": "Finance",
            "group_code": "Fin.147",
            "identifier": "Fin.147-DMSQ",
            "description": "DailyMissingSubsQuery",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "DailyMissingSubsICare",
            "process_code": "DMSI",
            "group": "Finance",
            "group_code": "Fin.148",
            "identifier": "Fin.148-DMSI",
            "description": "DailyMissingSubsICare",
            "frequency": "Daily",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "RPAOperationalEfficiency",
            "process_code": "RPAOE",
            "group": "IT",
            "group_code": "IT.001",
            "identifier": "IT.001-RPAOE",
            "description": "RPAOperationalEfficiency",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "TeamACDetail",
            "process_code": "TACD",
            "group": "IT",
            "group_code": "IT.002",
            "identifier": "IT.002-TACD",
            "description": "TeamACDetail",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "HPIPRetrieval",
            "process_code": "HPIP",
            "group": "Finance",
            "group_code": "FIN.149",
            "identifier": "FIN.149-TACD",
            "description": "HPIPRetrieval",
            "frequency": "Monthly Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "ActVsEst",
            "process_code": "ACTE",
            "group": "IT",
            "group_code": "IT.003",
            "identifier": "IT.003-ACTE",
            "description": "ActVsEst",
            "frequency": "Daily Plus",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "Mercury Returns Retrieval",
            "process_code": "MRR",
            "group": "Finance",
            "group_code": "Fin.150",
            "identifier": "Fin.150-MRR",
            "description": "Mercury Returns Retrieval",
            "frequency": "Weekly",
            "email": "kkashyap@prokarma.com"
        },
        {
            "process_name": "TaxFileRename",
            "process_code": "TFR",
            "group": "Finance",
            "group_code": "Fin.151",
            "identifier": "Fin.151-TFR",
            "description": "TaxFileRenaming",
            "frequency": "Weekly",
            "email": "kkashyap@prokarma.com"
        }
    ]
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/bot_machine_metrics -H 'Content-Type: application/json' -d '{
    "type": "bot_machine_metrics",
    "data": [
    	{
    		"displayName": "CPU Usage",
    		"metricName": "PercentProcessorTime",
    		"logType": "cpu"
    	},
    	{
    		"displayName": "Memory Usage",
    		"metricName": "PercentMemoryUsed",
    		"logType": "memory"
    	},
    	{
    		"displayName": "Disk Usage",
    		"metricName": "PercentDiskTime",
    		"logType": "disk"
    	},
    	{
    		"displayName": "Network - Bytes Received per Second",
    		"metricName": "BytesReceivedPerSec",
    		"logType": "network"
    	},
    	{
    		"displayName": "Network - Bytes Sent per Second",
    		"metricName": "BytesSentPerSec",
    		"logType": "network"
    	}
    ]
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/oem_machine_processes_mapping -H 'Content-Type: application/json' -d '{
	"type": "oem_machine_processes_mapping",
	"data": [
		{
			"hostname": "PVMXD658",
			"processes": ["AutomationAnywhere.Controlroom.Service"]
		},
		{
			"hostname": "PVMXD659",
			"processes": ["AutomationAnywhere.Controlroom.Service"]
		},
		{
			"hostname": "PVMXD660",
			"processes": ["AutomationAnywhere.Controlroom.Service"]
		},
		{
			"hostname": "PVMXD661",
			"processes": ["AutomationAnywhere.Controlroom.Service"]
		},
		{
			"hostname": "PVMXD662",
			"processes": ["sqlservr"]
		}
	]
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/oem_host_metrics -H 'Content-Type: application/json' -d '{
    "type": "oem_host_metrics",
    "data": [
        {
            "displayName": "System CPU",
            "metricType": "cpu",
            "metricName": "userCPU"
        },
        {
            "displayName": "Network IO Write",
            "metricType": "network",
            "metricName": "netiowrite",
            "componentName": "vmxnet3 Ethernet Adapter"
        }
    ]
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/oem_process_metrics -H 'Content-Type: application/json' -d '{
    "type": "oem_process_metrics",
    "data": [
        {
        	"displayName": "CPU",
            "metricName": "cpuPercantage"
        },
        {
        	"displayName": "Memory",
            "metricName": "memory"
        }
    ]
}'
echo '\n'

curl -XPOST ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/${INDEX_NAME}/_doc/metrics_mapping -H 'Content-Type: application/json' -d '{
    "type": "metrics_mapping",
    "data": [
    	{
    		"displayName": "CPU Usage",
    		"metricName": "win_cpu_Percent_Processor_Time",
    		"instanceName": "_Total"
    	},
    	{
    		"displayName": "Disk Usage",
    		"metricName": "win_disk_Percent_Free_Space",
    		"instanceName": "_Total"
    	}
    ]
}'
echo '\n'