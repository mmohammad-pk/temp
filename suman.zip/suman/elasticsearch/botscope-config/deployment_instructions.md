# RPA Monitoring Tool Deployment instructions

1. Checkout git repositories into same folder

	```console
	$ git clone https://github.com/ProKarma-Inc/prl-sprint-rpa-monitoring-config.git rpa-monitoring-config
	$ git clone https://github.com/ProKarma-Inc/prl-sprint-rpa-monitoring-api-.git rpa-monitoring-api
	$ git clone https://github.com/ProKarma-Inc/prl-sprint-rpa-monitoring-alert-.git rpa-monitoring-alert
	$ git clone https://github.com/ProKarma-Inc/prl-sprint-rpa-monitoring-ui.git rpa-monitoring-ui
	$ git clone https://github.com/ProKarma-Inc/prl-sprint-rpa-monitoring-ingest-.git rpa-monitoring-ingest
	```

2. Go into ```rpa-monitoring-config``` folder
	
	```console
	$ cd rpa-monitoring-config
	```

3. Build and run the docker image

	```console
	$ docker-compose build
	$ docker-compose up
	```

