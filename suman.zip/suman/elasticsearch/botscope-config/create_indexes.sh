ELASTICSEARCH_PROTOCOL=http
ELASTICSEARCH_ENDPOINT=localhost:9600
HTTP_METHOD=PUT

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/metadata_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 1, 
        "number_of_replicas" : 1 
    },
    "mappings" : {
        "properties":{  
			 "type":{  
				"type":"keyword"
			 },
			 "data":{  
				"type":"nested"
			 },
			 "create_time":{
				"type":"long"
			 },
			 "update_time":{
				"type":"long"
			 }
	  	}
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/process_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 3, 
            "number_of_replicas" : 1 
    },
    "mappings" : {
        "properties":{  
			 "trace_id":{  
				"type":"keyword"
			 },
			 "process_name":{  
				"type":"keyword"
			 },
			 "machine_name":{  
				"type":"keyword"
			 },
			 "bot_user_name":{  
				"type":"keyword"
			 },
			 "start_time":{
				"type":"long"
			 },
			 "end_time":{
				"type":"long"
			 },
			 "status":{
				"type":"keyword"
			 },
			 "create_time":{
				"type":"long"
			 },
			 "update_time":{
				"type":"long"
			 }
	  	}
    }
}'

echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/main_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 3, 
            "number_of_replicas" : 1 
    },
    "mappings" : {
        "properties":{  
			 "trace_id":{  
				"type":"keyword"
			 },
			 "span_id":{  
				"type":"keyword"
			 },
			 "process_name":{  
				"type":"keyword"
			 },
			 "bot_name":{  
				"type":"keyword"
			 },
			 "event_type":{  
				"type":"keyword"
			 },
			 "event_time":{  
				"type":"long"
			 },
			 "current_context":{  
				"type":"keyword"
			 },
			 "context_app":{  
				"type":"keyword"
			 },
			 "document_id":{  
				"type":"keyword"
			 },
			 "count":{  
				"type":"keyword"
			 },
			 "row_count":{  
				"type":"keyword"
			 },
			 "metric_flag":{  
				"type":"keyword"
			 },
			 "create_time":{
				"type":"long"
			 },
			 "update_time":{
				"type":"long"
			 }
		}
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/error_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 3, 
            "number_of_replicas" : 1 
    },
    "mappings" : {
        "properties":{  
			 "trace_id":{  
				"type":"keyword"
			 },
			 "span_id":{  
				"type":"keyword"
			 },
			 "process_name":{  
				"type":"keyword"
			 },
			 "bot_name":{  
				"type":"keyword"
			 },
			 "event_time":{  
				"type":"long"
			 },
			 "process_start_time":{  
				"type":"long"
			 },
			 "process_end_time":{  
				"type":"long"
			 },
			 "current_context":{  
				"type":"keyword"
			 },
			 "context_app":{  
				"type":"keyword"
			 },
			 "machine_name":{  
				"type":"keyword"
			 },
			 "bot_user_name":{  
				"type":"keyword"
			 },
			 "create_time":{
				"type":"long"
			 },
			 "update_time":{
				"type":"long"
			 }
	  	}
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/data_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 3, 
            "number_of_replicas" : 1 
    },
    "mappings" : {
        "properties":{  
			 "trace_id":{  
				"type":"keyword"
			 },
			 "span_id":{  
				"type":"keyword"
			 },
			 "process_name":{  
				"type":"keyword"
			 },
			 "bot_name":{  
				"type":"keyword"
			 },
			 "event_time":{  
				"type":"long"
			 },
			 "current_context":{  
				"type":"keyword"
			 },
			 "context_app":{  
				"type":"keyword"
			 },
			 "event_type":{  
				"type":"keyword"
			 },
			 "data":{  
				"type": "nested"
			 },
			 "create_time":{
				"type":"long"
			 },
			 "update_time":{
				"type":"long"
			 }
	  	}
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/reliability_metrics_index -H 'Content-Type: application/json' -d '{
    "settings" : {
        "number_of_shards" : 3, 
        "number_of_replicas" : 3 
    },
    "mappings" : {
        "properties":{ 
             "process_name":{ 
                "type":"keyword"
             },
             "interval":{ 
                "type":"keyword"
             },
             "metric_type":{ 
                "type":"keyword"
             },
             "aggregated_metric_value":{
                "type":"double"
             },
             "aggregated_metric_time":{
                "type":"long"
             },
             "metrics":{
                "type":"nested"
             }
        }
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/notification_index -H 'Content-Type: application/json' -d '{
    "settings": {
        "number_of_shards": 3,
        "number_of_replicas": 1
    },
    "mappings": {
        "properties": {
            "trace_id": {
				"type": "keyword"
			},
			"process_name": {
				"type": "keyword"
			},
			"machine_name": {
				"type": "keyword"
			},
			"bot_user_name": {
				"type": "keyword"
			},
			"bot_name": {
				"type": "keyword"
			},
			"span_id": {
				"type": "keyword"
			},
			"event_type": {
				"type": "keyword"
			},
			"event_time": {
				"type": "long"
			},
			"current_context": {
				"type": "keyword"
			},
			"context_app": {
				"type": "keyword"
			},
			"data": {
				"type": "nested"
			},
			"comments": {
				"type": "keyword"
			},
			"is_resolved": {
				"type": "boolean"
			},
			"asset_type": {
				"type": "keyword"
			},
			"asset_name": {
				"type": "keyword"
			},
			"metric_name": {
				"type": "keyword"
			},
			"metric_rule": {
				"type": "keyword"
			},
			"metric_value": {
				"type": "keyword"
			},
			"create_time": {
				"type": "long"
			},
			"update_time": {
				"type": "long"
			}
        }
    }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/botscope_compliance_report_summary -H 'Content-Type: application/json' -d '{
  "settings": {
    "number_of_shards": 3,
    "number_of_replicas": 3
  },
  "mappings": {
    "properties": {
      "process_name": {
        "type": "keyword"
      },
      "startTime": {
        "type": "long"
      },
      "endTime": {
        "type": "long"
      },
      "traceId": {
        "type": "keyword"
      },
      "compliance_status": {
        "type": "keyword"
      }
    }
  }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/botscope_compliance_report_details -H 'Content-Type: application/json' -d '{
  "settings": {
    "number_of_shards": 3,
    "number_of_replicas": 3
  },
  "mappings": {
    "properties": {
      "process_name": {
        "type": "keyword"
      },
      "traceId": {
        "type": "keyword"
      },
      "file_path": {
        "type": "keyword"
      },
      "masked_contents": {
        "type": "keyword"
      },
      "rule_violations": {
        "type": "nested"
      }
    }
  }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/botscope_compliance_rules_profiles_index -H 'Content-Type: application/json' -d '{
  "settings": {
    "number_of_shards": 3,
    "number_of_replicas": 3
  },
  "mappings": {
    "properties": {
      "master_profile": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 256
          }
        }
      },
      "custom_profile": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 256
          }
        }
      }
    }
  }
}'
echo '\n'

curl -X${HTTP_METHOD} ${ELASTICSEARCH_PROTOCOL}://${ELASTICSEARCH_ENDPOINT}/metrics_index -H 'Content-Type: application/json' -d '{
"settings" : {
      "index" : {
        "number_of_shards" : "3",
        "number_of_replicas" : "1"
      }
    },
    "mappings" : {
      "properties" : {
        "logType" : {
          "type" : "keyword"
        },
        "hostname" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "ignore_above" : 256,
              "type" : "keyword"
            }
          }
        },
        "metricName" : {
          "ignore_above" : 256,
          "type" : "keyword"
        },
        "appID" : {
          "ignore_above" : 256,
          "type" : "keyword"
        },
        "metricValue" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "ignore_above" : 256,
              "type" : "keyword"
            }
          }
        },
        "assetName" : {
          "type" : "keyword"
        },
        "postDate" : {
          "type" : "date"
        },
        "message" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "ignore_above" : 256,
              "type" : "keyword"
            }
          }
        },
        "assetType" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "ignore_above" : 256,
              "type" : "keyword"
            }
          }
        },
        "logTime" : {
          "type" : "double"
        }
      }
    }
}
'
echo '\n'